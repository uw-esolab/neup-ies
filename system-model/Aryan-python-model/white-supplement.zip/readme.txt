This thesis folder contains:

1). Thesis .pdf for "Thermodynamic Cycle Modeling of Integrated Lead-Cooled Fast Reactor and Concentrating Solar Power" by Brian T. White submitted 12/22/2022

2). Engineering Equation Solver cycle models for sCO2 Brayton and supercritical steam-Rankine
	i). working for EES Academic Professional V11.288-3D (2022-02-02) Build 22621
	ii). readme files for brief outline of model operation in each subfolder:
		- system-components -> procedures for important system components with an example case
		- supercritical_co2_brayton -> non-charging and charging configurations at different temperatures
		- supercritical_steam_rankine -> 'off', 'charging', 'discharging' modes of operation case studies
