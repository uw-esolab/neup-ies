sCO2 Brayton Cycle Configurations:
	-Charging:
		2-Cycle
		C-1HTR1T-ON
		C-2HTR3T-ON
	-Non-Charging
		C-LFR-CIRC
		C-LFR-PAR
		C-LFR-PRE

Each cycle configuration has various operating temperatures included with optimized spitter values, y_1 or y_2.

If the temperature for either cold or hot TES, LFR inlet or outlet temperatures, LFR heat input, or precooler temperature changes, a parametric study will need to be used to update splitter fraction values and maximize cycle efficiency. 