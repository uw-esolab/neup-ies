Folders for 3 modes of operation for Supercritical Steam-Rankine Cycle with on and off design:

	1). charging - 10%-100% modes of operation
	2). discharging - 10%-441% modes of operation
	3). off

		*each operation mode has specified TTD and DT values for FWHs scaled from the 100% discharging mode* 

Models:
	rankine-on-design
		-100% charging, 100% discharging, and off -> adjust which mode it is in by mode$ string ('D','C','O') 
		-TTD and DT values are set to acheive scaled UA values
	rankine-turbine-scaling
		-uses turbine scaling technique and fwh UA scaling for more accurate representations of off-design mass flow rate variation for efficiency calculations
	

To scale UA values (Patnode 2006 Thesis)
	1). adjust the cycle parameters (i.e. temperatures, mass flow rates, LFR/CSP heat inputs)

	2). run in desired mode by changing mode$ = ['D','C','O'] and go to arrays table.

	3). two UA values for ds, cond, dc (desuperheater, condenser, and draincooler)
		- UA_off_tot -> this is the calculated UA value that is being adjusted using TTD and DT to the Patnode 2006 predicted value
		- UA_tot_f -> this is Patnode 2006 predicted UA value for the systems mass flow rates and reference values
		- iterative by-hand process, change TTD and DT for FWH A-F until UA_off_tot ~= UA_tot_f